<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processing</title>
    <link rel="stylesheet" href="a-9-form-page.css">
</head>
<body>
    <header class="boundary">
        <h1>Congrats! You are signed up!</h1>
    </header>
    <div class="forerow">
    Family Name: <?php print $_POST['family-name']?>
    <br>
    Email: <?php print $_POST['email']?>
    <br>
    Password: <?php print $_POST['password']?>
    <br>
    State: <?php print $_POST['state']?>
    <br>
    Gender: <?php print $_POST['gender']?>
    <br>
    Feedback: <?php print $_POST['feedback']?>
    <br>
    Color: <?php print $_POST['color']?>
    </div>
</body>
</html>

<!--
photo tour
page layout    
family responsive
-->